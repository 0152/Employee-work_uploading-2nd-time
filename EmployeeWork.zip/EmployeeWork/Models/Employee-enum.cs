﻿namespace EmployeeWork.Models
{
    public enum Employee_enum
    {
        HourlyEmployee = 1,
        SalariedEmployee = 2,
        Manager = 3
    }
}
